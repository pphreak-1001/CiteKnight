chrome.runtime.onInstalled.addListener(() => {
  console.log("CiteKnight installed.");
});
